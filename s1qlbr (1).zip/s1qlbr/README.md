# S1QLBR

Gerador gratuito de queries para threat hunting, compatível com o Event Search do SentinelOne.
Escreva em português (ou inglês, espanhol, chinês) o que quer caçar e copie a query pronta.

Site: https://s1qlbr.com

## Como funciona

- **Sem IA (padrão):** um motor de regras em JavaScript monta a query no próprio navegador. Nada sai da máquina do usuário.
- **Motores grátis:** o `api.php` chama Groq ou Gemini com chaves guardadas no servidor, fora da pasta pública.
- **Chave própria:** o usuário pode usar a própria chave (OpenAI, Gemini, Claude, Groq, OpenRouter, DeepSeek, Ollama ou API compatível com OpenAI). A chave vai direto do navegador para o provedor.

## Estrutura

```
public_html/
  index.html               o gerador (HTML, CSS e JS num arquivo só)
  api.php                  intermediário dos motores grátis
  menu.js                  menu do topo, usado por todas as páginas
  s1.css                   visual das páginas internas
  contato/contato.php      Fale conosco (envia e-mail)
  analise/index.html       Análise de resultados (em breve)
  donate/donate.html       Apoie o projeto (em breve)
s1qlbr-config.modelo.php   modelo da configuração (sem chaves)
LEIA-ME-hostgator.txt      instalação na HostGator
identidade.md              marca, cores e tipografia
```

## Instalação

Veja o `LEIA-ME-hostgator.txt`. Resumo:

1. Copie `s1qlbr-config.modelo.php` para `s1qlbr-config.php` **fora** da `public_html`.
2. Cole as chaves do Gemini e do Groq, troque o `salt` e coloque seu e-mail em `contact`.
3. Envie o conteúdo de `public_html/` para a `public_html` do servidor, mantendo as pastas.

> O arquivo `s1qlbr-config.php` com as chaves reais **nunca** deve ir para o GitHub. O `.gitignore` já bloqueia esse arquivo.

## Aviso

Projeto independente, sem vínculo com a SentinelOne. SentinelOne e S1QL são marcas dos respectivos donos.
Revise sempre a query antes de rodar.
