# S1QLBR — Identidade da marca

Decidido em 11/11/2026.

## Nome e domínio

| Item | Valor |
|---|---|
| Marca / nome do sistema | **S1QLBR** |
| Domínio oficial | **s1qlbr.com** (hospedado na HostGator, SSL via AutoSSL) |
| Descrição curta | Gerador de queries para threat hunting |
| Modelo | Gratuito |

**Observação:** "S1QL" é o nome da linguagem de consulta da SentinelOne. O projeto é gratuito, o que reduz o risco. Mesmo assim, use um logo próprio, sem cores ou símbolos da SentinelOne. No texto do site, prefira a forma descritiva "compatível com SentinelOne".

## Logo

Canvas com todas as versões: https://claude.ai/artifact/L2uj8XfrRevjT5R9CUVopj

**Conceito do ícone**
- **Cilindro de banco de dados:** a base de eventos.
- **Faixa verde no meio do cilindro:** o registro que a query encontrou.
- **Lupa:** a consulta.

Nos favicons de 32 px e 16 px a lupa sai, para o ícone continuar legível.

**Wordmark**

O wordmark é escrito "S1QLBR" e cada parte tem um estilo:

| Parte | Fonte e peso | Cor no fundo escuro | Cor no fundo claro |
|---|---|---|---|
| "S1" | Space Grotesk 700 | Gelo `#E6F1F5` | Abismo `#0B1F2A` |
| "QL" | JetBrains Mono | Sinal `#B6F23A` | Sinal escuro `#3F7D0A` |
| "BR" | Space Grotesk 700 | `#A9BDC6` | `#5B6B73` |

### Ícone (SVG)

```svg
<svg width="120" height="120" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Ícone S1QLBR">
  <rect width="120" height="120" rx="26" fill="#0B1F2A"/>
  <path d="M24 51 A28 10 0 0 0 80 51 V70 A28 10 0 0 1 24 70 Z" fill="#B6F23A"/>
  <ellipse cx="52" cy="32" rx="28" ry="10" fill="none" stroke="#E6F1F5" stroke-width="6"/>
  <path d="M24 32 V88 A28 10 0 0 0 80 88 V32" fill="none" stroke="#E6F1F5" stroke-width="6" stroke-linejoin="round"/>
  <path d="M24 51 A28 10 0 0 0 80 51 M24 70 A28 10 0 0 0 80 70" fill="none" stroke="#E6F1F5" stroke-width="6"/>
  <circle cx="84" cy="84" r="16" fill="#0B1F2A" stroke="#B6F23A" stroke-width="7"/>
  <path d="M95.5 95.5 L105 105" stroke="#B6F23A" stroke-width="8" stroke-linecap="round"/>
</svg>
```

### Favicon (SVG simplificado)

```svg
<svg width="32" height="32" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">
  <rect width="120" height="120" rx="24" fill="#0B1F2A"/>
  <path d="M28 54 A32 11 0 0 0 92 54 V72 A32 11 0 0 1 28 72 Z" fill="#B6F23A"/>
  <ellipse cx="60" cy="34" rx="32" ry="11" fill="none" stroke="#E6F1F5" stroke-width="10"/>
  <path d="M28 34 V88 A32 11 0 0 0 92 88 V34" fill="none" stroke="#E6F1F5" stroke-width="10" stroke-linejoin="round"/>
</svg>
```

### Wordmark (HTML)

```html
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@700&family=JetBrains+Mono:wght@500&display=swap" rel="stylesheet">
<span style="font-family:'Space Grotesk',sans-serif;font-weight:700;letter-spacing:-0.03em;color:#E6F1F5">S1<span style="font-family:'JetBrains Mono',monospace;color:#B6F23A">QL</span><span style="color:#A9BDC6">BR</span></span>
```

## Cores

| Nome | Hex | Uso |
|---|---|---|
| Abismo | `#0B1F2A` | Fundo principal e texto em fundo claro |
| Sinal | `#B6F23A` | Destaque, somente sobre fundo escuro |
| Sinal escuro | `#3F7D0A` | Destaque sobre fundo claro |
| Gelo | `#E6F1F5` | Texto e traços sobre fundo escuro |
| Cinza | `#5B6B73` | Texto secundário em fundo claro |

## Tipografia

| Fonte | Uso |
|---|---|
| **Space Grotesk** | Títulos e texto |
| **JetBrains Mono** | "QL", código e rótulos |

As duas fontes são gratuitas e estão no Google Fonts.
